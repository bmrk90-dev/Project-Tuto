# Micro Tutorials (Web Test)
- Next.js 14 + API routes
- Ingen .env nødvendig (in-memory data)

## StackBlitz (quick)
1) Gå til stackblitz.com → Create → Upload Project
2) Last opp denne ZIP-en
3) I terminalen: `npm i` og `npm run dev`
4) Åpne preview-lenken
